/* Scripts for About page */
console.log('About page');