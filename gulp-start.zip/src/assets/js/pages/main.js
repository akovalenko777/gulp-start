/* Scripts for Main page */
console.log('Main page');