$(function(){
  console.log('%c HELLO!!!!', 'color:tomato;font-size:22px;font-weight:bold');
});
